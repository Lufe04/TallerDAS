package com.balitechy.spacewar.main;

import java.awt.Graphics;
import java.awt.image.BufferedImage;

public class SpriteBullet implements IBullet{
	
	private BufferedImage image;

    public SpriteBullet(BufferedImage image) {
        this.image = image;
    }

    @Override
    public void render(Graphics g, double x, double y) {
        g.drawImage(image, (int) x, (int) y, null);
    }
}
