/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.balitechy.spacewar.main;
import java.awt.image.BufferedImage;
import java.io.IOException;

/**
 *
 * @author Luisa Carpintero
 */
public abstract class IFactory {
     public abstract IPlayer createPlayerRenderer(BufferedImage image);
    public abstract IBullet createBulletRenderer(BufferedImage image);
    public abstract IBackgroundRenderer createBackgroundRenderer(BufferedImage image);
    
}
