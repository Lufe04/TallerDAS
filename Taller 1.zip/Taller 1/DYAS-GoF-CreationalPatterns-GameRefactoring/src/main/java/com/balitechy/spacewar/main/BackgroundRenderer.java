package com.balitechy.spacewar.main;

import java.awt.Canvas;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.IOException;

import java.awt.Canvas;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.IOException;

public class BackgroundRenderer implements IBackgroundRenderer {

    private BufferedImage background;

    public BackgroundRenderer(String imagePath) throws IOException {
        SpritesImageLoader bg = new SpritesImageLoader(imagePath);
        bg.loadImage();
        background = bg.getImage(0, 0, 640, 480); // Ajusta las coordenadas y el tamaño según sea necesario
    }

    @Override
    public void render(Graphics g, Canvas c) {
        g.drawImage(background, 0, 0, c.getWidth(), c.getHeight(), c);
    }
}
