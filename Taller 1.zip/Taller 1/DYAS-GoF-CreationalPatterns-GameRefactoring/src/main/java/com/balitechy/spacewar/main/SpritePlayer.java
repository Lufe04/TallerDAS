package com.balitechy.spacewar.main;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;

public class SpritePlayer implements IPlayer{
    private final BufferedImage image;

    public SpritePlayer(BufferedImage image) {
        this.image = image;
    }

    @Override
    public void render(Graphics g, double x, double y) {
        g.drawImage(image, (int) x, (int) y, null);
    }
}
