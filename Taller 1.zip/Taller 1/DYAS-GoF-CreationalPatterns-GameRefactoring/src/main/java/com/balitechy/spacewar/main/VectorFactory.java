/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.balitechy.spacewar.main;

import java.awt.image.BufferedImage;

/**
 *
 * @author Luisa Carpintero
 */
public class VectorFactory extends IFactory {
    @Override
    public IPlayer createPlayerRenderer(BufferedImage image) {
        return new VectorPlayer();
    }

    @Override
    public IBullet createBulletRenderer(BufferedImage image) {
        return new VectorBullet();
    }

    @Override
    public IBackgroundRenderer createBackgroundRenderer(BufferedImage image) {
        return new BackgroundRendererVector();
}
}
