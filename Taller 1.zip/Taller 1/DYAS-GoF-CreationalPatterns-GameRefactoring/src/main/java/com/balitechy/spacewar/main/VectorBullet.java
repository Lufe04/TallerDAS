/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.balitechy.spacewar.main;

import java.awt.Color;
import java.awt.Graphics;

/**
 *
 * @author Luisa Carpintero
 */
public class VectorBullet implements IBullet{
    @Override
    public void render(Graphics g, double x, double y) {
        g.setColor(Color.yellow);
        g.drawLine((int) x, (int) y, (int) x, (int) y - Bullet.HEIGHT);
    }
}
