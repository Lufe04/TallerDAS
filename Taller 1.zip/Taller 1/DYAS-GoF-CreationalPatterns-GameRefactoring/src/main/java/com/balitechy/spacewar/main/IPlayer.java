/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.balitechy.spacewar.main;

import java.awt.Graphics;

/**
 *
 * @author Luisa Carpintero
 */
public interface IPlayer {
    void render(Graphics g, double x, double y);
}
